// C program to check if the strings are anagrams or not

#include <stdio.h>

int checkanagram(char [], char []);

int main()
{
char a[100], b[100];

printf("Enter two strings : \n");
gets(a);
gets(b);

if (checkanagram(a, b) == 1)
printf("The strings are anagrams\n");
else
printf("The strings are not anagrams\n");

return 0;
}

int checkanagram(char a[], char b[])
{
int first[26] = {0}, second[26] = {0}, c=0;
while (a[c] != '\0')
{
first[a[c]-'a']++;
c++;
}

c = 0;

while (b[c] != '\0')
{
second[b[c]-'a']++;
c++;
}
for (c = 0; c < 26; c++)
{
if (first[c] != second[c])
return 0;
}

return 1;
}