//count a number using do while loop
#include<stdio.h>
void digit(int n){
    int count=0;
    do
    {
     n=n/10;
     ++count;
    }while(n!=0);
    printf("total digit : %d  ",count);
}

  int main()
  {
   int n;
   printf("Enter any number to count digit\n");
   scanf("%d",&n);
    digit(n) ;

  }