//	In short How to Copy one string to another using pointer.
#include<stdio.h>
#include<conio.h>
void main()
{
    char *str1, *str2;
    int i;
    clrscr();
    printf("Enter the string : ");
    scanf("%s", str2);
    for(i = 0; *str2 != '\0'; i++, str1++, str2++)
    *str1 = *str2;
    *str1 = '\0';
    str1 = str1 - i;
    printf("\nThe copied string is : %s", str1);
    getch();
}
