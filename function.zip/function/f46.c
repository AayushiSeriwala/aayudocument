//Eligibility of vote
#include<stdio.h>
void vote(int a){
    if(a>=18)
      printf("Eligible for voting");
       else
        printf("Not eligible for voting");
}
int main()
{
    int a;
    printf("Enter the age of person\n");
    scanf("%d",&a);
    vote(a);
}