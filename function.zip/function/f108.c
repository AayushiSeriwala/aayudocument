//find the sum of all even and odd using recursion
#include <stdio.h>
#include <stdlib.h>
void displayEvenOdd(int num, int limit);
int main()
{
    int lowerLimit, upperLimit;
    printf("Enter lower limit\n");
    scanf("%d",&lowerLimit);  

    printf("Enter upper limit\n");
    scanf("%d",&upperLimit);

    printf("Even/odd numbers from %d to %d are: ",lowerLimit,upperLimit);
    displayEvenOdd(lowerLimit,upperLimit);
    
    return 0;
}
void displayEvenOdd(int num, int limit)
{
    if(num>limit)
        return;
    printf("%d, ",num);
    displayEvenOdd(num + 2, limit);
}