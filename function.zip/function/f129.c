//Delete an element from an array at the specified position
#include <stdio.h>
 newinsertion(int *a,int n,int index)
 { 
    int i;
  for(i=index-1; i<n-1; i++)
        {
         a[i]=a[i+1];
           
        }
 }
 
 print(int a[],int n)
 { 
    int i;
    for(i=0; i<n; i++)
    {
         
        printf("%d ",a[i]);
         
    }
 	
 }
int main()
{
    int a[10000],i,n,index,new1;
   
    printf("Enter size of the array : ");
    scanf("%d", &n);
 
    printf("Enter elements in array : ");
    for(i=0; i<n; i++)
    {
        scanf("%d",&a[i]);
    }
    
    
	printf("Enter position should not greater than %d:",n);
    
	scanf("%d",&index);
    
	if(index<=n && index>0)
    {
 
        
		printf("\nbefore deletion  :");
 
     	print(a,n);
     	
        newinsertion(a,n,index);
 
        printf("\nafter   deletion :");
        
		print(a,n-1);
    }
    return 0;
} 