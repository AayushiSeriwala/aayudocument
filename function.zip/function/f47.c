//count a digit of number using while loop
#include<stdio.h>
void digit(int n,int count){
  
  while(n!=0)
   {
       n/=10;
       ++count;
   }
   printf("Number of digits=%d",count);
}
int main()
{
  int n,count=0;
  printf("Enter any number to count digit\n");
  scanf("%d",&n);
  digit(n,count);
}