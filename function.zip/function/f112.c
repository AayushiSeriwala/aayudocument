//remove all vowels from string using switch case
#include<stdio.h>
#include<string.h>
int isvowel(char);
int main()
{
    char str[100] ,new[100];
    int i,j=0;
    printf("Enter a string to remove vowels\n");
    gets(str);
     for(i=0;str[i]='\0';i++)
        {
          if(isvowel(str[i])==1) 
            {
                new[j]=str[i];
                j++;
            }
        }
        new[j]='\0';
        printf("string after removing vowels%s\n",new);
}
  int isvowel(char ch)
  {
     switch(ch)
     {
         case'a':
         case'e':
         case'i':
         case'o':
         case'u':
         case'A':
         case'E':
         case'I':
         case'O':
         case'U':
        default:
       return 1;
     
  }
  }