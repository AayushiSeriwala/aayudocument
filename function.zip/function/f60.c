//read numbers from a file and write even,odd and prime numbers to separate file
#include <stdio.h>
#include <stdlib.h>

int even(const int num);
int prime(const int num);
int main(){
   FILE * fptrinput,
   * fptreven,
   * fptrodd,
   * fptrprime;
   int num, success;
   fptrinput = fopen("file1.txt", "r");
   fptreven = fopen("even-numbers.txt" , "w");
   fptrodd = fopen("odd-numbers.txt" , "w");
   fptrprime= fopen("prime-numbers.txt", "w");
   if(fptrinput == NULL || fptreven == NULL || fptrodd == NULL || fptrprime == NULL){
      printf("Unable to open file.\n");
      exit(EXIT_FAILURE);
   }
   printf("File opened successfully. Reading integers from file. \n\n");
   while (fscanf(fptrinput, "%d", &num) != -1){
      if (prime(num))
         fprintf(fptrprime, "%d\n", num);
      else if (even(num))
         fprintf(fptreven, "%d\n", num);
      else
         fprintf(fptrodd, "%d\n", num);

   }
   fclose(fptrinput);
   fclose(fptreven);
   fclose(fptrodd);
   fclose(fptrprime);
   printf("Data written successfully.");
   return 0;
}
int even(const int num){
   return !(num & 1);
}
int prime(const int num){
   int i;
   if (num < 0)
      return 0;
   for ( i=2; i<=num/2; i++ ) {
      if (num % i == 0) {
         return 0;
      }
   }
   return 1;
}
