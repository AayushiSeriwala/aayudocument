//display all array elements using recursion
#include<stdio.h>
void PrintArray(int arr[], int i, int n)
{

    if(i>=n)
        return;
    printf("%d ",arr[i]);
    PrintArray(arr,i+1,n);
}
int main()
{
    int n,i;
    printf("Enter your array size:");
    scanf("%d",&n);
    int arr[n];
    printf("Enter the Array Element:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Array Element Are:");
    PrintArray(arr,0,n);
}
